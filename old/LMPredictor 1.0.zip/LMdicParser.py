import pickle 
"""
Generate a python dictionary that maps phenome class pairs
to predicted landmarks.

The input file follows the format:


# - g       (+g)
# - n       +g/+n/Nc
...


where the phenome pair and the prediction in each entry is seperated by tab(s).
Extra spaces and '\n' are allowed.
"""
LMs = [
'V',	#vowel LM			energy peak
'G',	#glide LM				energy dip
'Nc',	#nasal closure LM			abrupt onset of nasal
'Nr',	#nasal release LM			abrupt offset of nasal
'Fc',	#fricative closure LM		abrupt onset of frication
'Fr',	#fricative release LM		abrupt offset of frication
'Sc',	#stop closure LM			cessation of vocal tract activity due to oral closure
'Sr',	#stop release LM			abrupt release of burst energy due to oral release
'Tn',	#stridency onset LM		onset of stridency
'Tf',	#stridency offset LM		offset of stridency

    #(other possible types not dealt with here include abrupt onset and offset of liquids)

'Lc',	#liquid closure LM			abrupt onset of liquid
'Lr',	#liquid release LM			abrupt offset of liquid
]

import re

source = "phn_trans_to_lm.txt"
table = open(source,'r')
classes = ['#','v','g','n','fu','fn','fs','s','a']
dic = {}
for c in classes:
    dic[c] = {}
    
for line in table:
    line = line.strip('\n')
    if line!='':
        entry = re.split('\s*//\s*', line)[0].split('\t')
        f,a,t = entry[0].split()
        if len(entry)>1:
            lm = entry[1]
        else:
            lm = ''
        if f not in classes or t not in classes:
            print("Unknown phoneme class ", f)
        else:
            dic[f][t]=lm


out = open("LM_dic",'wb')
pickle.dump(dic, out)
out.close()
table.close()


